
baza <- read.csv("carvana.csv", stringsAsFactors = FALSE)

baza_1 <- baza[1:4999, ]
baza_2 <- baza[5000 : 6798, ]

apply(baza_1[, 18:25], 2, function(x){shapiro.test(x)})
apply(baza_2[, 18:25], 2, function(x){shapiro.test(x)})
